/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.practicemethods;
import javax.swing.*;
/**
 *
 * @author giquibod
 */
public class PracticeMethods {
    public static void introduce(){
        String choice;
        do{
            choice = JOptionPane.showInputDialog("a. name only\nb. name, age\nc. name, age, course").toLowerCase();
            if("abc".contains(choice)) break;
        }while(true);
        String name = "", age = "", course = "";
        if("abc".contains(choice)) name = JOptionPane.showInputDialog("Enter name:");
        if("bc".contains(choice)) age = JOptionPane.showInputDialog("Enter age:");
        if("c".contains(choice)) course = JOptionPane.showInputDialog("Enter course:");
        
        if("a".contains(choice)) introduce(name);
        if("b".contains(choice)) introduce(name, age);
        if("c".contains(choice)) introduce(name, age, course);
    }
    
    public static void introduce(String name){
        JOptionPane.showMessageDialog(null, "Hello, I am " + name + "!");
    }
    public static void introduce(String name, String age){
        JOptionPane.showMessageDialog(null, "Hello, I am " + name + "! I am " + age + "-yrs old.");
    }
    public static void introduce(String name, String age, String course){
        JOptionPane.showMessageDialog(null, "Hello, I am " + name + "! I am " + age + "-yrs old. I am in " + course + ".");
    }

    public static void main(String[] args) {
        String choice;
        do{
            choice = JOptionPane.showInputDialog("1: Calculate\n2: Introduce");
            if(choice.equalsIgnoreCase("1") || choice.equalsIgnoreCase("2")) break;
        }while(true);
        if(choice.equalsIgnoreCase("1")) calculate();
        else introduce();
    }
    public static void calculate(String choice, int num1, int num2){
        if("a".contains(choice)) JOptionPane.showMessageDialog(null, add(num1, num2));
        else if("b".contains(choice)) JOptionPane.showMessageDialog(null, subtract(num1, num2));
        else if("c".contains(choice)) JOptionPane.showMessageDialog(null, multiply(num1, num2));
        else JOptionPane.showMessageDialog(null, divide(num1, num2));
    }
    public static void calculate(String choice, double num1, double num2){
        if("a".contains(choice)) JOptionPane.showMessageDialog(null, add(num1, num2));
        else if("b".contains(choice)) JOptionPane.showMessageDialog(null, subtract(num1, num2));
        else if("c".contains(choice)) JOptionPane.showMessageDialog(null, multiply(num1, num2));
        else JOptionPane.showMessageDialog(null, divide(num1, num2));
    }
    
    public static void calculate(){
        String choice;
        do{
            choice = JOptionPane.showInputDialog("a. add\nb. subtract\nc. multiply\n d. divide").toLowerCase();
            if("abcd".contains(choice)) break;
        }while(true);
        String x, y;
        x = JOptionPane.showInputDialog("Enter your 1st numeric string value:");
        y = JOptionPane.showInputDialog("Enter your 1st numeric string value:");
        if(x.contains(".") || y.contains(".")){
            double num1, num2;
            System.out.print("Contains a dot");
            num1 = Double.parseDouble(x);
            num2 = Double.parseDouble(y);
            calculate(choice, num1, num2);
        }else{
            int num1, num2;
            num1 = Integer.parseInt(x);
            num2 = Integer.parseInt(y);
            calculate(choice, num1, num2);
        }
        
    }
    
    public static int add(int x, int y){ 
        return x + y;
    }
    public static double add(double x, double y){ 
        return x + y;
    }
    
    public static int subtract(int x, int y){
        return x - y;
    }
    public static double subtract(double x, double y){
        return x - y;
    }
    
    public static int multiply(int x, int y){
        return x * y;
    }
    public static double multiply(double x, double y){
        return x * y;
    }
    
    public static int divide(int x, int y){
        return x / y;
    }
    public static double divide(double x, double y){
        return x / y;
    }
}
